## Antichrist Blog
Telegram - [Antichrist (Creator)](https://t.me/antichristone), subscription or life?

## Start
```
proxychains python3 main.py
```

## License
**Mozilla Public License 2.0**

